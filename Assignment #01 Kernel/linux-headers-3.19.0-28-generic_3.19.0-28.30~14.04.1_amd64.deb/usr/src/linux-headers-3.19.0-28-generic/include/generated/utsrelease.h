#define UTS_RELEASE "3.19.0-28-generic"
#define UTS_UBUNTU_RELEASE_ABI 28
